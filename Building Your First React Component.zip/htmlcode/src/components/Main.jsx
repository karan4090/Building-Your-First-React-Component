import React from 'react';
import './Main.css'; // Component-specific styles

function Main() {
  return (
    <main className="main">
      <p>This is the main content area where all the magic happens!</p>
    </main>
  );
}

export default Main;
